package listaExerciciosMatriz;

import java.text.DecimalFormat;
import java.util.Random;

public class ex06 {

	public static void main(String[] args) {
		Random rng = new Random();
		DecimalFormat fmt = new DecimalFormat("00.00");
		
		double[][] matriz = new double[12][4];
		double precoAnual = 0;
		
		for (int i = 0; i < matriz.length; i++) {
			double precoMensal = 0;
			System.out.print("\nMês " + (i+1) +": " );
			for (int j = 0; j < matriz[i].length; j++) {
				matriz[i][j] =  rng.nextDouble(20, 50);// cria valores aleatórios para os preços das vendas
				System.out.print(fmt.format(matriz[i][j]) + "\t");
				precoMensal += matriz[i][j];
			}
			precoAnual += precoMensal;
			System.out.print("\nValor aproximado de vendas do mês " + (i+1) + ": " + fmt.format(precoMensal));
			System.out.println();
		}
		System.out.print("\nValor aproximado de vendas no ano: " + fmt.format(precoAnual));
	}

}
