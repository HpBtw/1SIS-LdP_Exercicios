import java.util.Scanner;

public class exercicio06 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		System.out.print("Informe a quantia de elementos dentro do vetor: ");
		int array = kb.nextInt();
		int[] valor = new int[array];
		boolean status = true;
	
		for (int i = 0; i < valor.length; i++) {
			System.out.print("Insira um valor: ");
			valor[i] = kb.nextInt();
		}
		
		if(array != 1) {
			for (int i = 0; i < valor.length - 1; i++) {
				if(valor[i] % 2 == valor[i+1] % 2) {
					status = false;
					break;
				}
			}
			
			if(status) {
				System.out.println("É especial");
			} else {
				System.out.println("Não é especial");
			}
		}
		kb.close();
	}
}


