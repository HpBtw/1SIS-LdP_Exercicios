import java.util.Scanner; 


public class Exercicio03 {

	public static void main(String[] args) {
		
		Scanner kb = new Scanner(System.in);
		int valor, cont = 1, fat = 1;
		
		System.out.println("Digite um valor inteiro e positivo.");
		valor = kb.nextInt();
		
		if (valor < 0) {
			System.out.println("O valor deve ser inteiro e positivo.");
		}
		else {
			while (cont <= valor) {
				fat = fat * cont;
				cont = cont + 1;
				// cont++
			}
			System.out.println(fat);
		}
		
		
		
	
	}

}
