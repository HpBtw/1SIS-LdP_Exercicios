package listaExerciciosMatriz;

import java.util.Random;

public class ex02 {

	public static void main(String[] args) {
		Random rng = new Random();
		
		int[][] matriz = new int[5][5];
		int soma = 0;
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				matriz[i][j] = rng.nextInt(51);
				System.out.print(matriz[i][j] + "\t");
			}
			System.out.println();
		}
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if(i + j < matriz.length-1) {
					soma += matriz[i][j];
				} else {
					break;
				}
			}
		}
		
		System.out.println("Soma dos números acima da diagnal secundária: " + soma);
	}
}
