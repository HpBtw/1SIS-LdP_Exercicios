package listaExerciciosMatriz;

import java.util.Random;

public class ex04 {

	public static void main(String[] args) {
		Random rng = new Random();
		
		int[][] matrizX = new int[2][2];
		int[][] matrizY = new int[2][2];
		int[][] matrizZ = new int[2][2];
		
		System.out.println("MatrizX:");
		
		for (int i = 0; i < matrizX.length; i++) {
			for (int j = 0; j < matrizX[i].length; j++) {
				matrizX[i][j] = rng.nextInt(101);
				System.out.print(matrizX[i][j] + "\t");
			}
			System.out.println();
		}
		
		System.out.println("\nMatrizY:");
		
		for (int i = 0; i < matrizY.length; i++) {
			for (int j = 0; j < matrizY[i].length; j++) {
				matrizY[i][j] = rng.nextInt(101);
				System.out.print(matrizY[i][j] + "\t");
			}
			System.out.println();
		}
		
		System.out.println("\nMatrizZ (Subtração XxY:");
		
		for (int i = 0; i < matrizZ.length; i++) {
			for (int j = 0; j < matrizZ[i].length; j++) {
				matrizZ[i][j] = matrizX[i][j] - matrizY[i][j];
				System.out.print(matrizZ[i][j] + "\t");
			}
			System.out.println();
		}

	}

}
