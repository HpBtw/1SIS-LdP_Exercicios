
public class exercicio07 {

	public static void main(String[] args) {
		

	}

}
