import java.util.Scanner;
import java.text.DecimalFormat;

public class ex1 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		DecimalFormat mascara = new DecimalFormat("0.00");
		
		double valorHora, hora, salarioBruto, ir, inss, sindicato, salarioLiquido;
		
		System.out.println("Insira o valor ganho por hora trabalhada.");
		valorHora = kb.nextDouble();
		
		System.out.println("Insira o número de horas trabalhadas no mês");
		hora = kb.nextDouble();

		if (hora > 0 && valorHora > 0) {
			salarioBruto = hora * valorHora;
			ir = salarioBruto * 0.11;
			inss = salarioBruto * 0.08;
			sindicato = salarioBruto * 0.05;
			salarioLiquido = salarioBruto - ir - inss - sindicato;
			
			System.out.println("Salário Bruto: R$" + mascara.format(salarioBruto));
			System.out.println("IR (11%): R$" + mascara.format(ir));
			System.out.println("INSS (8%): R$" + mascara.format(inss));
			System.out.println("Sindicato (5%): R$" + mascara.format(sindicato));
			System.out.print("Salario Líquido: R$" + mascara.format(salarioLiquido));
		}
		else {
			System.err.print("Insira um número de horas/valor ganho por hora válido.");
		}
		
		kb.close();
		
	}

}
