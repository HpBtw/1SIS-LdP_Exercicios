import java.util.Scanner; 

public class Exercicio10 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		int valor = 0, divisor;
		
		System.out.println("Informe um valor inteiro: ");
		valor = kb.nextInt();
		
		for (divisor = -valor; divisor <= valor; divisor++) {
			if (divisor != 0 && valor % divisor == 0) {
				System.out.print(divisor + "  ");
				}
			}
		}
}