import java.util.Random;
import java.util.Scanner;

public class sprint {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		Random rng = new Random();
		
		int quantia;
		System.out.print("Informe a quantia de equipes participantes: ");
		quantia = kb.nextInt();
		
		int[] equipe = new int[quantia];
		double[] design = new double[quantia];
		boolean status;
		
		// Entrada de dados - ID das equipes, notas de design
		
		if (quantia <= 0) {
			System.err.println("Informe um número válido! Reinicie o programa.");
		} else {
		for (int i = 0; i < equipe.length;) {
			System.out.println();
			System.out.print("Informe o número-identificação (de 1 à 100) da " + (i+1) + "ª equipe: ");
			equipe[i] = kb.nextInt();
			status = false;
			if (equipe[i] < 1 || (equipe[i] > 100)) {
				status = true;
				System.err.print("Número de equipe inválido, escolha outro.\n");
			}
			
			for (int j = 0; j < i; j++) {
				if (equipe[i] == equipe[j]) {
					status = true;
					System.err.print("Número de equipe já selecionado, escolha outro.\n");
					break;
				}
			}
				if (!status) {
					for (int k = 0; k < 1;) {	
						System.out.print("Informe a nota de design do robô (entre 0 à 10) da equipe '" + equipe[i] + "': ");
						design[i] = kb.nextDouble();
						
						if (design[i] < 0.00 || design[i] > 10.00) {
							i++;
							k++;
						} else {
							System.err.println("Nota inválida, tente novamente.");
						}
					}
				}
			}
		}
		kb.close();
	}
	
	public static int[][] ffa(int quantia) {
		int[][] m = new int [quantia][quantia];
		
		return m;
	}

}
