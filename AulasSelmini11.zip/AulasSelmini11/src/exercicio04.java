import java.util.Iterator;
import java.util.Random;

public class exercicio04 {
	
	public static void main(String[] args) {
		Random rng = new Random();
		
		int[][] matriz = new int[3][6];
		String[] tipo = new String[3];
		tipo[0] = "eletronicos";
		tipo[1] = "roupas";
		tipo[2] = "alimentos";
		int[][] totais = new int[3][6];
		
		for (int i = 0; i < matriz.length; i++) {
			int vendas = 0, soma = 0;
			for (int j = 0; j < matriz[i].length; j++) {
				 matriz[i][j] = rng.nextInt(40);
				 vendas = matriz[i][j];
				 soma += matriz[i][j];
				 System.out.print("Vendas no mês " + (j+1) + " na área de " + tipo[i] + ": " + vendas + "\n");
			}
			System.out.print("Soma das vendas da categoria '" + tipo[i] + "': " + soma + "\n");
			System.out.println();		
		}
		
	}
}
