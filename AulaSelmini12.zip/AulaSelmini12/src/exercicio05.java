import java.util.Random;

public class exercicio05 {

	public static void main(String[] args) {
		Random rng = new Random();
		
		int[] v = new int[10];
		
		for (int i = 0; i < v.length; i++) {
			v[i] = rng.nextInt(1, 11);
		}
		
		print(v);
		
		inversion(v);
	}
	
	public static void print(int[] v) {
		for (int i = 0; i < v.length; i++) {
			System.out.print(v[i] + "\t");
		}
	}
	
	public static void inversion(int[] v) {
		int aux;
		System.out.println();
		
		for (int i = 0; i < v.length / 2; i++) {
			aux = v[i];
			v[i] = v[v.length - 1 - i];
			v[v.length - 1 - i] = aux;
		}
		
		for (int i = 0; i < v.length; i++) {
			System.out.print(v[i] + "\t");
		}
	}
}