import java.util.Scanner;
import java.text.DecimalFormat;

public class ex3 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		DecimalFormat mascara = new DecimalFormat("0.00");
		
		double salario, consumo, valorFinal, valorMetro;
		
		System.out.println("Insira o salário mínimo vigente.");
		salario = kb.nextDouble();
		
		System.out.println("Insira o consumo mensal de água, em metros cúbicos.");
		consumo = kb.nextDouble();
		
		if (salario > 0 && consumo > 0) {
			valorMetro = salario / 130;
			valorFinal = consumo * valorMetro;
			System.out.println("Valor a pagar: R$" + mascara.format(valorFinal));
		}
		else {
			System.err.println("Insira um salário ou um consumo maior que 0.");
		}
		kb.close();
	}
}
