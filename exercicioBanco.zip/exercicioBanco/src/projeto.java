import javax.swing.JOptionPane;

public class projeto {

	public static void main(String[] args) {
		String[] nome = new String[3];
		int[] cpf = new int[nome.length];
		double[] saldo = new double[nome.length];
		boolean status = true;
		boolean validate;
		int i = 0;
		
		// StringBuilder impede a criação repetitiva de uma string,
		// StringBuilder builder = new Builder
		
		while (status == true) {
			try {
				if (nome[i] == null) {
					nome[i] = "";
				}
				
				int opcao = Integer.parseInt(JOptionPane.showInputDialog("Prezado(a) " + nome[i] + "\nSelecione uma opção:\n1. Abrir conta\n2. Sacar\n3. Depositar\n4. Consultar saldo\n5. Trocar de conta\n6. Finalizar"));
				
				switch (opcao) {
				case 1:
					nome[i] = JOptionPane.showInputDialog("Informe seu nome");
					cpf[i] = Integer.parseInt(JOptionPane.showInputDialog("Prezado(a) " + nome[i] + " informe seu cpf"));
					saldo[i] = Double.parseDouble(JOptionPane.showInputDialog("Prezado(a) " + nome[i] + " informe o saldo na conta"));
					break;
				case 2:
					validate = false;
					do {
						if (nome[i] == "") {
							erro();
							break;
						} else {
						double sacado = sacar(saldo, nome, i);
						JOptionPane.showMessageDialog(null, "Você sacou " + sacado + " reais.");
						saldo[i] -= sacado;
						validate = true;
						}
					} while (validate == false);
					break;
				case 3:
					validate = false;
					do {
						if (nome[i] == "") {
							erro();
							break;
						} else {
						double depositado = depositar(saldo, nome, i);
						JOptionPane.showMessageDialog(null, "Você depositou " + depositado + " reais.");
						saldo[i] += depositado;
						}
					} while (validate == false);
					break;
				case 4:
					validate = false;
					do {
						if (nome[i] == "") {
							erro();
							break;
						} else {
						consultar(saldo, i);
						}
					} while (validate == false);
					break;
				case 5:
					i++;
					JOptionPane.showMessageDialog(null, "Conta alternada.");
					break;
				case 6:
					JOptionPane.showMessageDialog(null, "Operação encerrada.");
					status = false;
					break;
				default:
					JOptionPane.showMessageDialog(null, "A opção deve ser um número entre 1 e 6.");
					break;
				}
			}
			catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "A opção deve ser um número.");
			}
			catch(ArrayIndexOutOfBoundsException e) {
				JOptionPane.showMessageDialog(null, "Limite de contas atingido.");
			}
		}
	}
	
	public static double sacar(double[] saldo, String[] nome, int i) {
		int j = 0;
		while (true) {
			do {
				double sacado = Double.parseDouble(JOptionPane.showInputDialog("Prezado(a) " + nome[i] + ", quanto você deseja sacar?"));
				if (sacado > saldo[i]) {
					JOptionPane.showMessageDialog(null, "Você não possui saldo o suficiente");
				} else {
					j++;
					return sacado;
				}
			} while (j > 1);
		}
	}
	
	public static double depositar (double[] saldo, String[] nome, int i) {
		while (true) {
			double depositado = Double.parseDouble(JOptionPane.showInputDialog("Prezado(a) " + nome[i] + ", quanto você deseja depositar?"));
			return depositado;
		}
	}
	
	public static void consultar (double[] saldo, int i) {
		JOptionPane.showMessageDialog(null, "Você possui R$" + saldo[i] + " na sua conta");
	}
	
	public static void erro () {
		JOptionPane.showMessageDialog(null, "Você precisa ter uma conta cadastrada pra essa ação.");
	}
}