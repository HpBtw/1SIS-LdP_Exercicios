import java.util.Scanner;

public class exercicio05 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		int[] numero = new int[10];
		
		for (int i = 0; i < numero.length; i++) {
			System.out.print("Informe um número: ");
			numero[i] = kb.nextInt();
		}
		System.out.print("\n Sequência original: ");
		
		for (int i = 0; i < numero.length; i++) {
			System.out.print(numero[i]);
			
		}
		System.out.print("\n Sequência invertida: ");
		
		for (int iaux = numero.length - 1; iaux >= 0; iaux--) {
			System.out.print(numero[iaux]);
		}
		kb.close();
	}

}
