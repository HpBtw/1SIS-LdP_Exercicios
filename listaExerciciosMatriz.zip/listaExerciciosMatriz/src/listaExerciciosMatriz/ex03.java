package listaExerciciosMatriz;

import java.util.Random;

public class ex03 {

	public static void main(String[] args) {
		Random rng = new Random();
		
		int[][] matrizA = new int [3][3];
		int[][] matrizB = new int [3][3];
		int[][] matrizC = new int [3][3];
		
		System.out.println("Matriz A:");
		
		for (int i = 0; i < matrizA.length; i++) {
			for (int j = 0; j < matrizA[i].length; j++) {
				matrizA[i][j] = rng.nextInt(21);
				System.out.print(matrizA[i][j] + "\t");
			}
			System.out.println();
		}
		
		System.out.println("\nMatriz B:");
		
		for (int i = 0; i < matrizB.length; i++) {
			for (int j = 0; j < matrizB[i].length; j++) {
				matrizB[i][j] = rng.nextInt(21);
				System.out.print(matrizB[i][j] + "\t");
			}
			System.out.println();
		}
		
		System.out.println("\nMatriz C (Soma AxB):");
		for (int i = 0; i < matrizC.length; i++) {
			for (int j = 0; j < matrizC[i].length; j++) {
				matrizC[i][j] = matrizA[i][j] + matrizB[i][j];
				System.out.print(matrizC[i][j] + "\t");
			}
			System.out.println();
		}
	}
}