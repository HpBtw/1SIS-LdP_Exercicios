package manipulacaodetexto;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class exemplo {
	public static void main(String[] args) throws IOException {
		
		String linha;
		FileReader file;
		BufferedReader buffer;
		
		file = new FileReader("d:\\arquivo\\aluno.txt");
		buffer = new BufferedReader(file);
		
		while((linha = buffer.readLine()) != null) {
			System.out.println(linha);
		}
		
		buffer.close();

	}
}
