import java.util.Iterator;
import java.util.Scanner;

public class exercicio05 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		int[] numero = new int[5];
		
		for (int i = 0; i < numero.length; i++) {
			System.out.println("Informe um número");
			numero[i] = kb.nextInt();
		}
		
		System.out.println(" ");
		
		for (int iaux = numero.length - 1; iaux >= 0; iaux--) {
			System.out.print(numero[iaux]);
		}
	}

}
