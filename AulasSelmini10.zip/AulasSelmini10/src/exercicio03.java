import java.util.Scanner;

public class exercicio03 {	
	
	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		int[] aluno = new int[10];
		int posicaoAluno = 1, maiores = 0;
		double[] nota = new double[4];
		
		System.out.println("Bem vindo!");
		
		for (int i = 0; i < aluno.length; i++) {
			int posicaoNota = 1;
			double notaTotal = 0;
			System.out.println(" ");
			
			for (int j = 0; j < nota.length; j++) {
				
				System.out.print("Informe a nota " + posicaoNota + " do aluno " + posicaoAluno +": ");
				nota[j] = kb.nextDouble();
				notaTotal =+ nota[j];
				
				if (notaTotal / 4 >= 6) {
					maiores++;
				}
				posicaoNota++;
			}
			posicaoAluno++;
		}
		System.out.println(" ");
		System.out.print("Quantia de alunos com média igual ou maior que 6: " + maiores);
		
		kb.close();		
	}
}