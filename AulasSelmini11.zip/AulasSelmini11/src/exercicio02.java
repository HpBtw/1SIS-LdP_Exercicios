import java.util.Random;

public class exercicio02 {

	public static void main(String[] args) {
		
		Random rng = new Random();
		
		int[][] matriz = new int[10][10];
		int maior = 0;
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				matriz[i][j] = rng.nextInt(25);
				System.out.print(matriz[i][j] + "\t");
				
				if (matriz[i][j] > maior) {
					maior = matriz[i][j];
				}
			}
			System.out.println();
		}
		
		System.out.print("Maior valor " + maior +"\n");
		System.out.println("Posições:");
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if(matriz[i][j] == maior) {
					System.out.println("(" + i + "," + j + ")");
				}
			}
			
		}
	}
}
