import java.util.Random;

public class exercicio01 {

	public static void main(String[] args) {
		
		Random rng = new Random();
		
		int[][] matriz = new int[4][4];
		int dp = 0, ds = 0;
		
		for (int i = 0; i < matriz.length; i++) {
			for(int j = 0; j < matriz.length; j++) {
				matriz[i][j] = rng.nextInt(10);
				
				// teste para diagonal principal
				if(i == j) {
					dp += matriz[i][j];
				}
				
				// teste para diagonal secundária
				if(i + j == matriz.length-1) {
					ds += matriz[i][j];
				}
				
			}
		}
		
		for (int i = 0; i < matriz.length; i++) {
			for(int j = 0; j < matriz[i].length; j++) {
				System.out.print(matriz[i][j] + "\t");
			}
			System.out.println();
		}
		

		
		//dp = matriz[0][0] + matriz[1][1] + matriz[2][2] + matriz[3][3]; //
		// ds = matriz[0][3] + matriz[1][2] + matriz[2][1] + matriz[3][0]; //
		
		System.out.print("Soma da diagonal principal: "+ dp +"\n");
		System.out.print("Soma da diagonal secundária: " + ds);
	}
}
