import java.util.Scanner; 

public class Exercicio11 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		int valor, divisor;
		
		System.out.println("Informe um valor");
		valor = kb.nextInt();
		

		for (divisor = 2; divisor < valor; divisor++) {
			if (valor % divisor != 1) {
				System.out.println("Não é um número primo");
				break;
			} else {
				System.out.println("É um número primo");
				}
			}
		}
	}