import java.text.DecimalFormat;
import java.util.Scanner;

public class exercicio09 {

		public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		DecimalFormat mascara = new DecimalFormat("00.00");
	
		double folha = 0, media;
		int total;
		
		System.out.print("Informe a quantia de funcionários: ");
		total = kb.nextInt();
		int[] quantia = new int[total];
		String[] nome = new String[total];
		double[] salario = new double[total];
		
		
		for (int i = 0; i < quantia.length; i++) {
			kb.nextLine(); // usado pra resetar o nextLine e evitar erros
			
			System.out.print("\nInforme o nome do funcionário " + (i+1) + ": ");
			nome[i] = kb.nextLine();

			System.out.print("Informe o salário do funcionário " + (i+1) + ": ");
			salario[i] = kb.nextDouble();
			
			folha = folha + salario[i];
		}
		
		media = folha / quantia.length;
		
		System.out.print("\nA folha de pagamento será R$:" + mascara.format(folha));
		System.out.print("\nA média salarial paga é de R$S:" + mascara.format(media));
		
		kb.close();
	}
}
