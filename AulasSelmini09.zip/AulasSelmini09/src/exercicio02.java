import java.util.Scanner; 

public class exercicio02 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		int numero;
		// multiplicador sera o cont
		String resposta;
		
		// valor nao alteravel que sera verdade pra sempre, ou seja, será executado pra sempre ou até um break
		while(true){
			System.out.println("Digite o número a ser calculado: ");
			numero = kb.nextInt();
			int multiplicador = 0;
			// substitui o int multiplicador do começo do codigo, assim resetando por completo o programa
			
			while(multiplicador <= 10) {
				System.out.println(numero + " * " + multiplicador + " = " + (numero * multiplicador));
				multiplicador++;
			}
			System.out.println("\nDeseja outra tabuada? (s/n)");
			// \n da um enter antes da proxima linha, ou seja, 
			resposta = kb.next();
			
			if (resposta.equalsIgnoreCase("n")) {
				break;
				// quebra o while true
			}
		}
	}
}