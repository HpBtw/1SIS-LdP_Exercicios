import java.util.Random;

public class exercicio08 {

	public static void main(String[] args) {
		
		// Math.random(); //
		// cria um numero aleatorio entre 0 e 1 //
		
		Random rng = new Random();
		int[] x = new int[10];
		boolean status;
//		int x = rd.nextInt();
//		int y = rd.nextInt(5); // cria um valor abaixo de 5 e igual ou maior que 0
//		int z = rd.nextInt(10, 20); // cria numeros entre 10 e 19
		
//		System.out.println(x);
//		System.out.println(y);
//		System.out.println(z);
		
		for (int i = 0; i < x.length;) {
			x[i] = rng.nextInt(10, 101);
			status = false;
			for (int j = 0; j < i; j++) {
				if (x[i] == x[j]) {
					status = true;
					break;
				}
			}
			if(!status) {
				System.out.print(x[i] + " ");
				i++;
			}
		}
	}

}