import java.util.Scanner;

public class exercicio03 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		int x1, x2, x3;
		
		System.out.print("Informe o valor 1: ");
		x1 = kb.nextInt();

		System.out.print("Informe o valor 2: ");
		x2 = kb.nextInt();

		System.out.print("Informe o valor 3: ");
		x3 = kb.nextInt();
		
		checkMaior(x1, x2, x3);
		
		kb.close();
	}
	
	public static void checkMaior(int x1, int x2, int x3) {
	
		int maior = Integer.MIN_VALUE;
		
		if (x1 > maior) {
			maior = x1;
		}
		
		if (x2 > maior) {
			maior = x2;
		}
		
		if (x3 > maior) { 
			maior = x3;
		}
		System.out.print("Maior valor informado: " + maior);
	}
}
