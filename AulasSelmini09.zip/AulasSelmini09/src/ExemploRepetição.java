/*
 * programa para ler 2 valores (o primeiro valor deverá ser menor que o segundo). Seu programa deverá
 * imprimir todos os numeros ímpares entre o primeiro valor e o segundo valor. (inclusive).
 */

import java.util.Scanner;

public class ExemploRepetição {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		int valor1, valor2;
		
		System.out.println("Digite o valor 1 (menor que o segundo valor).");
		valor1 = kb.nextInt();
		
		System.out.println("Digite o valor 2");
		valor2 = kb.nextInt();
		
		if (valor1 < valor2) {
			while (valor1 <= valor2) {
				if (valor1 % 2 == 1) {
					System.out.print(valor1 + " ");
				}
				valor1 = valor1 + 1;
			}
		}
		else {
			System.err.println("O primeiro valor é igual ou maior que o segundo.");
		}
		
		
		kb.close();
	}
}