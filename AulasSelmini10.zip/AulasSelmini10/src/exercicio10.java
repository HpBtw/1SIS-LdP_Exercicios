import java.util.Random;

public class exercicio10 {

	public static void main(String[] args) {
		Random rng = new Random();
		int[] nmr = new int[rng.nextInt(5, 12)];
		int aux;
		// varia o tamanho da array entre 5 e 11
		
		// armazenar os valores, comando que preenche a array com valores à serem trabalhados
		System.out.print("Valor-base gerado: ");
		
		for (int i = 0; i < nmr.length; i++) {
			nmr[i] = rng.nextInt(11); // gera um número < 11
			System.out.print(nmr[i] + " ");
		}
		
		
		// ordenação --> ordem crescente
		for (int j = 0; j < nmr.length; j++) { // é necessário criar outro for pra que o comando abaixo seja repetido
			for (int i = 0; i < nmr.length-1; i++) { // como existe um x+1, subtrai-se 1 do length pra não estourar o tamanho
				if (nmr[i] > nmr[i+1]) {
					aux = nmr[i];
					nmr[i] = nmr[i+1];
					nmr[i+1] = aux; // coração da ordenação
				}
			}
		}
		
		
		
		// impressão após a ordenação
		System.out.print("\nValor pós inversão: "); // atalho: foreach - ctrl+spc
		for (int i : nmr) { // comando utilizado para representar cada elemento dentro do vetor, assim, não controlando sua orientação (forEach)
							   // esse comando executa e imprime os valores do i
			System.out.print(i + " ");
		}

	}

}