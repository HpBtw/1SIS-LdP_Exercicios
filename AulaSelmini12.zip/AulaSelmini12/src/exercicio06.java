import java.util.Random;

public class exercicio06 {

	public static void main(String[] args) {
		Random rng = new Random();
		
		int[][] matriz = new int[3][3];
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				matriz[i][j] = rng.nextInt(10);
			}
		}
		
		print(matriz);
		maior(matriz);
		int[] maior = maior(matriz);
		printMaior(maior, matriz);
	}
	
	public static void print(int[][] matriz) {
		
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				System.out.print(matriz[i][j] + "\t");
			}
			System.out.println();
		}
	}
	
	public static int[] maior(int[][] matriz) {
		int[] maior = new int[matriz.length];
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				if (matriz[i][j] > maior[i]) {
					maior[i] = matriz[i][j];
				}
			}
		}
		return maior;
	}
	
	public static void printMaior (int[] maior, int[][] matriz) {
		int[] maiorNum = (maior);
		
		System.out.println();
		for (int i = 0; i < matriz.length; i++) {
			System.out.println("Maior número da linha " + (i+1) + ": " + maiorNum[i]);
		}
	}
}