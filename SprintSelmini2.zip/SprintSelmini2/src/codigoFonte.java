import java.util.Scanner;

public class codigoFonte {

	public static void main(String[] args) {
		
		Scanner kb = new Scanner(System.in);
		
		int passos = 0, passosMax = 0, energia, energiaInicial = 300, energiaGasta, aux = 0;
		String direcao;
		
		System.out.println("Você é o robô BMO e está tentando recuperar o seu controle");
		System.out.println("Você possui " + energiaInicial + "/160kW disponíveis.");
		System.out.println("São gastos 10 kW para avançar cada casa.");
		System.out.println("Os comandos de direção aceitos para locomoção são: 'direita', 'esquerda', 'cima', 'baixo'.");
		System.out.println("Os números para locomoção aceitos são todos pertencentes ao conjunto dos inteiros.");
		
		while (passosMax < 3) {
			System.out.println("O robô percorreu " + passos);
			System.out.print("Insira a direção para o robô percorrer: ");
			direcao = kb.next();
				if (direcao.equalsIgnoreCase("direita")) {
					System.out.print("Insira o número de passos à serem percorridos: ");
					passos = kb.nextInt();
					passosMax = passosMax + passos;
				} else {
					System.err.println("Insira uma direção válida!");
			}
		}
		
		while (passosMax < 4) {
			System.out.print("Insira a direção para o robô percorrer: ");
			direcao = kb.next();
				if (direcao.equalsIgnoreCase("baixo")) {
					System.out.print("Insira o número de passos à serem percorridos: ");
					passos = kb.nextInt();
					passosMax = passosMax + passos;
				} else {
					System.err.println("Insira uma direção válida!");
			}
		}
		
		while (passosMax < 4) {
			System.out.println("O robô percorreu " + passos);
			System.out.print("Insira a direção para o robô percorrer: ");
			direcao = kb.next();
				if (direcao.equalsIgnoreCase("direita")) {
					System.out.print("Insira o número de passos à serem percorridos: ");
					passos = kb.nextInt();
					passosMax = passosMax + passos;
				} else {
					System.err.println("Insira uma direção válida!");
			}
		}
		
		while (passosMax < 2) {
			System.out.println("O robô percorreu " + passos);
			System.out.print("Insira a direção para o robô percorrer: ");
			direcao = kb.next();
				if (direcao.equalsIgnoreCase("cima")) {
					System.out.print("Insira o número de passos à serem percorridos: ");
					passos = kb.nextInt();
					passosMax = passosMax + passos;
				} else {
					System.err.println("Insira uma direção válida!");
			}
		}
		
		while (passosMax < 2) {
			System.out.println("O robô percorreu " + passos);
			System.out.print("Insira a direção para o robô percorrer: ");
			direcao = kb.next();
				if (direcao.equalsIgnoreCase("direita")) {
					System.out.print("Insira o número de passos à serem percorridos: ");
					passos = kb.nextInt();
					passosMax = passosMax + passos;
				} else {
					System.err.println("Insira uma direção válida!");
			}
		}
		
		while (passosMax < 1) {
			System.out.println("O robô percorreu " + passos);
			System.out.print("Insira a direção para o robô percorrer: ");
			direcao = kb.next();
				if (direcao.equalsIgnoreCase("baixo")) {
					System.out.print("Insira o número de passos à serem percorridos: ");
					passos = kb.nextInt();
					if (passos > passosMax) {
						passos = aux;
						passos = passosMax - aux;
					}
					passosMax = passosMax + passos;
				} else {
					System.err.println("Insira uma direção válida!");
			}
		}
		System.out.println("!!!");
		
	}
}