import java.util.Scanner;

public class exercicio01 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		int x;
		
		System.out.print("Informe um valor: ");
		x = kb.nextInt();
		
		print(x);
		
		kb.close();
	}
	public static void print(int x) {
		for (int i = -x; i <= x;  i++) {
			if (i != 0 && x % i == 0) {
				System.out.print(i + "\t");
			}
		}
	}
}