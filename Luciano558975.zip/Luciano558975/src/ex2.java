import java.util.Scanner;
import java.text.DecimalFormat;

public class ex2 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		DecimalFormat mascara = new DecimalFormat("0.00");
		
		double maca, morango, valorMaca, valorMorango, valor, peso;
		
		System.out.print("Insira, em kg, a quantia de maçãs compradas: ");
		maca = kb.nextDouble();
		
		System.out.print("Insira, em kg, a quantia de morangos compradas: ");
		morango = kb.nextDouble();
		
		if (morango <= 0 && maca <= 0) {
			System.err.println("Compre maçãs ou morangos para ser possível calcular o preço.");
		}
		else {
			peso = morango + maca;
			
			if (morango <= 5) {
				valorMorango = morango * 2.5; 
			}
			else {
				valorMorango = morango * 2.2;
			}
			if (maca <= 5) {
				valorMaca = maca * 1.8;
			}
			else {
				valorMaca = maca * 1.5;
			}			
			valor = valorMaca + valorMorango;
			
			if (valor > 25 || peso > 8) {
				valor = valor * 0.90;
			}
			System.out.print("Valor no terminal: R$" + mascara.format(valor));
		}
		kb.close();
	}
}
