import java.text.DecimalFormat;
import java.util.Random;
import java.util.Scanner;

public class exercicio03 {

	public static void main(String[] args) {

		Random rng = new Random();
		Scanner kb = new Scanner(System.in);
		DecimalFormat mascara = new DecimalFormat("00.00");
		
		int[][] matriz = new int[10][12];
		int maior = Integer.MIN_VALUE, menor = Integer.MAX_VALUE, auxMaior = 0, auxMenor = 0;
		
		for (int i = 0; i < matriz.length; i++) {
			double media = 0;
			
			for (int j = 0; j < matriz[i].length; j++) {
				matriz[i][j] = rng.nextInt(0, 26);
				media = media + matriz[i][j];
				
				System.out.print(matriz[i][j] + "\t");
			}
			
			media = media / matriz[i].length;
			
			if (media > maior) {
				auxMaior = i;
				maior = (int) media;
			}
			
			if (media < menor) {
				auxMenor = i;
				menor = (int) media;
			}
 			
			System.out.println("Média de temperatura do mês : " + mascara.format(media));
			System.out.println();
		}
		
		System.out.print("O ano " + (auxMaior+1) + " teve a maior temperatura média\n");
		System.out.print("O ano " + (auxMenor+1) + " teve a menor temperatura média");
	}
}
