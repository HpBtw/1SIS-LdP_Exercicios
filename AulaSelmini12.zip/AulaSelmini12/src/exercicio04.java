import java.util.Scanner;

public class exercicio04 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		int a, b, c;
		double x1, x2, delta;
		
		System.out.print("Informe o valor A: ");
		a = kb.nextInt();
		
		System.out.print("Informe o valor B: ");
		b = kb.nextInt();
		
		System.out.print("Informe o valor C: ");
		c = kb.nextInt();

		delta = Math.pow(b, 2) - 4 * a * c;
		
		if(delta < 0) {
			System.out.println("A equação não tem raíz real.");
		} else {
			System.out.print("Delta: " + delta);
			
			positivo(a, b, c, delta);
			x1 = positivo(a, b, c, delta);
			
			negativo(a, b, c , delta);
			x2 = negativo(a, b, c, delta);
		
			System.out.print("\nx1: " + x1);
			System.out.print("\nx2: " + x2);
			
			kb.close();
		}
	}
	
	public static double positivo(int a, int b, int c, double delta) {
		
		double x1;
		
		x1 = (-b + Math.sqrt(delta)) / (2 * a);
		
		return x1;
	}
	
	public static double negativo(int a, int b, int c, double delta) {
		
		double x2;
		
		x2 = (-b - Math.sqrt(delta)) / (2 * a);
		
		return x2;
	}
}