import java.util.Scanner;

public class exercicio02 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		System.out.print("Insira a palavra a ser rotacionada: ");
		String palavra = kb.next();
		
		System.out.print("\nInsira o número da rotação: ");
		int rotar = kb.nextInt();
		
		int[] valorUnicode = new int[palavra.length()];
		char[] c = new char[palavra.length()];
		
		System.out.println("\nValores unicode de cada caracter da palavra:");
		for (int i = 0; i < palavra.length(); i++) {
			c[i] = palavra.charAt(i);
			valorUnicode[i] = (int) c[i];
			System.out.print(valorUnicode[i] + "\t");
		}
		
		System.out.println("\nValores unicodes depois da rotação:");
		
		int[] valorRotado = rotacionar(valorUnicode, rotar);
		
		for (int i = 0; i < palavra.length(); i++) {
			System.out.print(valorRotado[i] + "\t");
		}
		
		System.out.println("\nPalavra após a rotação:");
		
		char[] cRotado = new char[palavra.length()];
		for (int i = 0; i < palavra.length(); i++) {
			cRotado[i] = (char) valorRotado[i];
			System.out.print(cRotado[i]);
		}

	}
	
	public static int[] rotacionar(int[] valorUnicode, int rotar) {
		int[] valorRotado = new int[valorUnicode.length];
		
		for (int i = 0; i < valorUnicode.length; i++) {
			valorRotado[i] = valorUnicode[i] + rotar;
			if (valorRotado[i] == 91) {
				valorUnicode[i] = 65;
			}
			else if (valorRotado[i] >= 123) {
				valorUnicode[i] = 97;
			}
		}
		
		return valorRotado;
	}

}
