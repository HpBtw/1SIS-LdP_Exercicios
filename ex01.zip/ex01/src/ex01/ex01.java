package ex01;

import java.util.Random;
import java.util.Scanner;

public class ex01 {

	public static void main(String[] args) {
		Random rng = new Random();
		Scanner kb = new Scanner(System.in);
		
		System.out.print("Informe a ordem da matriz: ");
		int ordem = kb.nextInt();
		
		int cont = 1;
		int[][] m = new int[ordem][ordem];
		
		System.out.println();
		
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m[i].length; j++) {
				// m[i][j] = rng.nextInt(10);
				m[i][j] = cont++;
				System.out.print(m[i][j] + "\t");
			}
			System.out.println();
		}
		System.out.println();
		
		for (int j = m.length-1; j >= 0; j--) {
			for (int i = 0; i < m.length; i++) {
				System.out.print(m[i][j] + "\t");
			}
			System.out.println();
		}
		
	}

}
