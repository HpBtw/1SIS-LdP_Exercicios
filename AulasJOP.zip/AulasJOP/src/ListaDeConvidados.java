import java.util.Scanner;
import javax.swing.JOptionPane;

public class ListaDeConvidados {

	public static void main(String[] args) {
		
		String[] lista = new String[10];
		boolean func = false;
		
		do {			
			int opcao = Integer.parseInt(JOptionPane.showInputDialog("Menu de opções:\n1. Cadastrar\n2. Pesquisar\n3. Imprimir\n4. Finalizar"));
		
			if (opcao < 1 || opcao > 4) {
				JOptionPane.showMessageDialog(null, "Opção inválida");
			} else {
				for (int i = 0; i < lista.length;) {
					if (opcao == 1) {
						lista[i] = (JOptionPane.showInputDialog("Cadastre um convidado."));
						i++;
						break;
					}
					else if (opcao == 2) {
						String pesquisa = JOptionPane.showInputDialog("Pesquise por um convidado.");
						//pesquisar(pesquisa, lista);
					}
					else if (opcao == 3) {
						JOptionPane.showMessageDialog(null, lista);
					}
					else {
						func = true;
					}
				}
			}
		} while (!func);
	}
	
//	public static String pesquisar(String pesquisa, String[] lista) {
//		String convidado = "convidado";
//		boolean status = false;
//		
//		char[] c = pesquisa.toCharArray();
//		
//		for (int i = 0; i < c.length; i++) {
//			String analise = lista[i];
//			char[] cLista = analise.toCharArray();
//			for (int j = 0; j < lista.length; j++) {
//			}
//		}
//		
//		return convidado;
//	}

}
