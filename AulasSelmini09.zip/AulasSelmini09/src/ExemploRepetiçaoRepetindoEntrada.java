import java.util.Scanner;

public class ExemploRepetiçaoRepetindoEntrada {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		int valor1, valor2;
		
		do {
			System.out.println("Digite o valor 1 (menor que o segundo valor).");
			valor1 = kb.nextInt();
			
			System.out.println("Digite o valor 2");
			valor2 = kb.nextInt();
			
			if (valor1 >= valor2) {
				System.out.println("Valores inválidos! Digite novos valores");
			}
		} while(valor1 >= valor2);

		
		while (valor1 <= valor2) {
				if (valor1 % 2 == 1) {
					System.out.print(valor1 + " ");
				}
				valor1 = valor1 + 1;
		}
		kb.close();
	}
}