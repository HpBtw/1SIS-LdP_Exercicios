import java.util.Random;
import java.util.Scanner;

public class exercicio03 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		System.out.print("Informe a quantia de palavras no banco: ");
		int quantia = kb.nextInt();
		
		String[] palavra = fillBank(quantia);
		String palavraEscolhida = select(palavra, quantia);
		forca(palavraEscolhida);
		
	}
	
	public static String[] fillBank(int quantia) {
		Scanner kb = new Scanner(System.in);
		
		String[] palavra = new String[quantia];
		
		for (int i = 0; i < palavra.length; i++) {
			System.out.print("Digite a  " + (i+1) + "º palavra: ");
			palavra[i] = kb.next();
		}
		return palavra;
	}
	
	public static String select (String[] palavra, int quantia) {
		Random rng = new Random();
		
		int seletor = rng.nextInt(1, (quantia+1));
		
		String palavraEscolhida = palavra[seletor-1];
		
		return palavraEscolhida;
	}

	public static void forca (String palavraEscolhida) {
		Scanner kb = new Scanner(System.in);
		
		int erros = 0;
		char[] c = new char[palavraEscolhida.length()];
		char[] cPalavra = palavraEscolhida.toCharArray();
		boolean perdeu = false;
		
		System.out.println("\nVocê pode errar até 6 vezes!");
		System.out.print("A palavra é: ");
		
		for (int i = 0; i < palavraEscolhida.length(); i++) {
			c[i] = '_';
			System.out.print(" " + c[i]);
		}
		
		for (int i = 0; i < palavraEscolhida.length();) {
			int validate = palavraEscolhida.length();
			if (erros < 6 ) {
				System.out.print("\nInforme um caracter: ");
				c[i] = kb.next().charAt(0);
				System.out.print("Palavra: ");
				for (int j = 0; j < cPalavra.length; j++) {
					if (cPalavra[j] == c[i]) {
						System.out.print(c[i] + " ");
						i++;
						validate--;
					}
				}
				
				if (validate == palavraEscolhida.length()) {
					System.out.print("\nErrado! Quantia de erros: " + (i+1));
					erros++;
				}
			} else {
				System.out.println("Excedeu a quantia de erros, reinicie o programa!");
				perdeu = true;
				break;
			}
		}
		
		if (!perdeu) {
			System.out.println("\nParabéns, você conseguiu! A palavra era: " + palavraEscolhida);
		}
	}
}
