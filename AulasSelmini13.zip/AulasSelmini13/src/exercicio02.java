import java.util.Scanner;

public class exercicio02 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String palavra, codificada;
		int deslocamento;
		
		System.out.print("Palavra a ser codificada --> ");
		palavra = sc.next();
		System.out.print("Deslocamento --> ");
		deslocamento = sc.nextInt();
		
		codificada = codificar(palavra, deslocamento);
		
		System.out.println("Palavra codificada --> " + codificada);
		
		sc.close();
	}
	
	public static String codificar(String palavra, int deslocamento) {
		char letra, letraCodificada;
		String palavraCodificada = "";
		
		for(int i = 0; i < palavra.length(); i++) {
			letra = palavra.charAt(i);
			if(Character.isUpperCase(letra)) {
				letraCodificada = (char)((letra - 'A' + deslocamento) % 26 + 'A');
				palavraCodificada += letraCodificada;
			}
		}
		
		return palavraCodificada;
	}

}
