import java.util.Scanner;

public class Exercicio07 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		double salario = 0, desconto = 0, renda, valorFinal = 0;
		long cpf = 0;
		int dependente = 0, salarioMin = 1412;
		String comando = "";
		
		while ((comando.equals("s")) || cpf == 0) {
		System.out.print("Informe o CPF: ");
		cpf = kb.nextLong();
		System.out.print("Declare o salário: ");
		salario = kb.nextDouble();
		System.out.print("Informe a quantia de dependentes: ");
		dependente = kb.nextInt();
		desconto = dependente * 0.05;
		renda = salario - salario * desconto;
		
			if (renda < salarioMin * 2) {
				valorFinal = renda;
				}
			else if (renda > salarioMin * 2 && renda < salarioMin * 3) {
				valorFinal = renda * 0.05;
			}
			else if (renda > salarioMin * 3 && renda < salarioMin * 5) {
				valorFinal = renda * 0.1;
			}
			else if (renda > salarioMin * 5 && renda < salarioMin * 7) {
				valorFinal = renda * 0.15;
			}
			else {
				valorFinal = renda * 0.2;
				}
			
			System.out.print("Seu cpf é: " + cpf);
			System.out.println(" ");
			System.out.print("Sua renda líquida é " + renda);
			System.out.println(" ");
			System.out.print("O número de dependentes é " + dependente);
			System.out.println(" ");
			System.out.print("O valor final a ser pago será R$" + valorFinal);
			System.out.println(" ");
			System.out.print("Deseja contribuir com outro CPF? (s/n)");
			comando = kb.next();
		}
		System.out.println("Programa encerrado.");
	}
}
