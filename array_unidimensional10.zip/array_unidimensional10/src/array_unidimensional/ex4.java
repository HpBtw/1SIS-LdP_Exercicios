package array_unidimensional;

import java.util.Scanner;

public class ex4 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		double[] temp = new double[12];
		int tempTotal = 0;
		String[] mes = {"janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", 
						"agosto", "setembro", "outubro", "novembro", "dezembro"};
		
		//variavel i controla as posiçoes
		for (int i = 0; i < temp.length; i++) {
			System.out.println("Informe a temperatura do mes de " + mes[i] + " ");
			temp[i] = kb.nextDouble();
			tempTotal = (int) (tempTotal + temp[i]);
		}
		
		double media = (tempTotal / temp.length);
		System.out.println("Media anual " + media);
		
		System.out.println("Meses com a temperatura acima da média: ");
		
		for (int i = 0; i < temp.length; i++) {
			if (temp[i] > media) {
				System.out.println(mes[i] + " temperatura: " + temp[i] + "°C");
			}
		}
	}
}
