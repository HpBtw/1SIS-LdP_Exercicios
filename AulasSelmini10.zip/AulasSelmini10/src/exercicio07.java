import java.util.Scanner;

public class exercicio07 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);

	}

}
