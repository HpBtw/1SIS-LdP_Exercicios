package ex01;

import java.util.Random;
import java.util.Scanner;

public class exTreino {

	public static void main(String[] args) {
		Random rng = new Random();
		Scanner kb = new Scanner(System.in);

		String letra;
		
		System.out.print("Informe a ordem da matriz: ");
		int ordem = kb.nextInt();
		
		int[][] m = new int[ordem][ordem];
		
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m.length; j++) {
				m[i][j] = rng.nextInt(150);
				System.out.print(m[i][j] + "\t");
			}
			System.out.println();
		}
		
		readData(m);
		printData(m);
		
		System.out.print("Digite S para soma e M para média: ");
	}
	
	public static int somar(int[][] m) {
		int total = 0;
		
		for (int i = 0; i < (m.length-1) / 2; i++) {
			for (int j = 1+i; j < m[i].length-1-i; j++) {
				total += m[i][j];
			}
		}
		
		return total;
	}
	
	public static void readData(int[][] m) {
		
	}
	
	public static void printData(int[][] m) {
		
	}
}
