import java.util.Scanner;

public class exercicio01 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		int rep = 1;
		double numero, maior = Double.MIN_VALUE;
		// Integer pra inteiro
		
		while (rep <= 3) {
			System.out.println("Insira um número: ");
			numero = kb.nextDouble();
			
			// É importante colocar a primeira repetição pra variável não armazenar o menor numero possivel de cara (nao entendi o pq)
			if (rep == 1 || numero > maior) {
				maior = numero;
			}
			rep = rep + 1;
		}
		System.out.println(maior);
		
		kb.close();
	}
}
