import java.util.Random;

public class exercicio05 {

	public static void main(String[] args) {
		Random rng = new Random();
		
		int[][] matriz = new int[5][6];
		int[][] alterado = new int[6][5];
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				matriz[i][j] = rng.nextInt(0, 7);
				System.out.print(matriz[i][j] + "\t");
			}
			System.out.println();
		}
		System.out.println();
		
		for (int i = 0; i < alterado.length; i++) {
			for (int j = 0; j < alterado[i].length; j++) {
				System.out.print(matriz[j][i] + "\t");
			}
			System.out.println();
		}
	}
}
