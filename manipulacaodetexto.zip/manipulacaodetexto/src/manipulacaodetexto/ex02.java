package manipulacaodetexto;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ex02 {
	public static void main(String[] args) {
		
		FileReader file;
		BufferedReader buffer;
		String ln;
		String[] aux;
		double x, y, z;
		int naoTriangulos = 0, esc = 0, equil = 0, iso = 0;
		
		try {
			file = new FileReader("dados.txt");
			buffer = new BufferedReader(file);
			
			while((ln = buffer.readLine()) != null) {
				aux = ln.split(";");
				x = Double.parseDouble(aux[0]);
				y = Double.parseDouble(aux[1]);
				z = Double.parseDouble(aux[2]);
				
				if (y + z > x && x + z > y && x + y > z) {
					if (x == z && x == y) {
						equil++;
					}
					else if (x != z && x != y && y != z) {
						esc++;
					}
					else {
						iso++;
					}
					
				} else {
					naoTriangulos++;
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("Erro ao encontrar o arquivo");
		} catch (IOException e) {
			System.out.println("Erro ao ler o arquivo");
		}
		System.out.print("\nNão triângulos: " + naoTriangulos + "\nEscalenos: " + esc + "\nEquiláteros: " + equil + "\nIsósceles: " + iso);
	}
}

