import java.util.Scanner;

public class Robo {

	public static void main(String[] args) {
		
		Scanner kb = new Scanner(System.in);
		
		int distancia, energia, energiaInicial = 160, energiaGasta;
		String direcao;
		
		System.out.println("Você é o robô BMO e está tentando recuperar o seu controle");
		System.out.println("Você possui " + energiaInicial + "/160kW disponíveis.");
		System.out.println("São gastos 10 kW para avançar cada casa.");
		System.out.println("Os comandos de direção aceitos para locomoção são: 'direita', 'esquerda', 'cima', 'baixo'.");
		System.out.println("Os números para locomoção aceitos são todos pertencentes ao conjunto dos inteiros.");
		
		System.out.println(" ");
		System.out.println("Insira uma direção para o robô.");
		direcao = kb.next();
		
		System.out.println("Insira o número de casas à serem percorridas.");
		distancia = kb.nextInt();
		
		if (direcao.equalsIgnoreCase("direita") && distancia == 3) {
			energiaGasta = distancia * 10;
			energia = energiaInicial - energiaGasta;
			
			System.out.println(" ");
			System.out.println("Você avançou 3 casas para a direita, chegando na casa 'D1'.");
			System.out.println("Você utilizou " + energiaGasta + "kW para isso. Você possui " + energia + "/160kW disponíveis.");
			
			System.out.println(" ");
			System.out.println("Insira uma direção para o robô.");
			direcao = kb.next();
			
			System.out.println("Insira o número de casas à serem percorridas.");
			distancia = kb.nextInt();
			
			if (direcao.equalsIgnoreCase("baixo") && distancia == 4) {
				energiaGasta = distancia * 10;
				energia = energia - energiaGasta;
				
				System.out.println(" ");
				System.out.println("Você avançou 4 casas para baixo, chegando na casa 'D5'.");
				System.out.println("Você utilizou " + energiaGasta + "kW para isso. Você possui " + energia + "/160kW disponíveis.");	
				
				System.out.println(" ");
				System.out.println("Insira uma direção para o robô.");
				direcao = kb.next();
				
				System.out.println("Insira o número de casas à serem percorridas.");
				distancia = kb.nextInt();
				
				if (direcao.equalsIgnoreCase("direita") && distancia == 4) {
					energiaGasta = distancia * 10;
					energia = energia - energiaGasta;
					
					System.out.println(" ");
					System.out.println("Você avançou 4 casas para direita, chegando na casa 'H5'.");
					System.out.println("Você utilizou " + energiaGasta + "kW para isso. Você possui " + energia + "/160kW disponíveis.");
					
					System.out.println(" ");
					System.out.println("Insira uma direção para o robô.");
					direcao = kb.next();
					
					System.out.println("Insira o número de casas à serem percorridas.");
					distancia = kb.nextInt();
					
					if (direcao.equalsIgnoreCase("cima") && distancia == 2) {
						energiaGasta = distancia * 10;
						energia = energia - energiaGasta;
						System.out.println(" ");
						System.out.println("Você avançou 2 casas para cima, chegando na casa 'H3'.");
						System.out.println("Você utilizou " + energiaGasta + "kW para isso. Você possui " + energia + "/160kw.");
						
						System.out.println(" ");
						System.out.println("Insira uma direção para o robô.");
						direcao = kb.next();
						
						System.out.println("Insira o número de casas à serem percorridas.");
						distancia = kb.nextInt();
						
						if (direcao.equalsIgnoreCase("direita") && distancia == 2) {
							energiaGasta = distancia * 10;
							energia = energia - energiaGasta;
							System.out.println(" ");
							System.out.println("Você avançou 2 casas para direita, chegando na casa 'J3'.");
							System.out.println("Você utilizou " + energiaGasta + "kW para isso. Você possui " + energia + "/160kW.");
							
							System.out.println(" ");
							System.out.println("Insira uma direção para o robô.");
							direcao = kb.next();
							
							System.out.println("Insira o número de casas à serem percorridas.");
							distancia = kb.nextInt();
							
							if (direcao.equalsIgnoreCase("baixo") && distancia == 1) {
								energiaGasta = distancia * 10;
								energia = energia - energiaGasta;
								
								System.out.println(" ");
								System.out.println("Você avançou 1 casa para baixo, chegando na casa 'J4', portanto concluiu o circuito.");
								System.out.println("Você utilizou " + energiaGasta + "kW para isso. Você possui " + energia + "/160kW.");
								System.out.println(" ");
								System.out.println("Parabéns! :)");
							}
							else {
								System.out.println(" ");
								System.out.println("Você inseriu um número de casas e/ou uma direção inválidas e bateu na parede. :(");
								System.out.println("Reinicie o programa para tentar novamente.");
							}
						}
						else {
							System.out.println(" ");
							System.out.println("Você inseriu um número de casas e/ou uma direção inválidas e bateu na parede. :(");
							System.out.println("Reinicie o programa para tentar novamente.");
						}
					}
					else {
						System.out.println(" ");
						System.out.println("Você inseriu um número de casas e/ou uma direção inválidas e bateu na parede. :(");
						System.out.println("Reinicie o programa para tentar novamente.");
					}
				}
				else {
					System.out.println(" ");
					System.out.println("Você inseriu um número de casas e/ou uma direção inválidas e bateu na parede. :(");
					System.out.println("Reinicie o programa para tentar novamente.");
				}
			}
			else {
				System.out.println(" ");
				System.out.println("Você inseriu um número de casas e/ou uma direção inválidas e bateu na parede. :(");
				System.out.println("Reinicie o programa para tentar novamente.");
			}
		}
 		else {
			System.out.println(" ");
			System.out.println("Você inseriu um número de casas e/ou uma direção inválidas e bateu na parede. :(");
			System.out.println("Reinicie o programa para tentar novamente.");
		}
		
		kb.close();
	}
}