import java.util.Random;
import java.util.Scanner;

public class sprintRascunho {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		int quantia;
		System.out.print("Informe a quantia de equipes participantes: ");
		quantia = kb.nextInt();
		
		int[] equipes = new int[quantia];
		double[] design = new double[quantia];
		boolean status;
		
		// Entrada de dados - ID das equipes, notas de design
		
		if (quantia <= 0) {
			System.err.println("Informe um número válido! Reinicie o programa.");
		} else {
		for (int i = 0; i < equipes.length;) {
			System.out.println();
			System.out.print("Informe o número-identificação (de 1 à 100) da " + (i+1) + "ª equipe: ");
			equipes[i] = kb.nextInt();
			status = false;
			if (equipes[i] < 1 || (equipes[i] > 100)) {
				status = true;
				System.err.print("Número de equipe inválido, escolha outro.\n");
			}
			
			for (int j = 0; j < i; j++) {
				if (equipes[i] == equipes[j]) {
					status = true;
					System.err.print("Número de equipe já selecionado, escolha outro.\n");
					break;
				}
			}
				if (!status) {
					for (int k = 0; k < 1;) {	
						System.out.print("Informe a nota de design do robô (entre 0 à 10) da equipe '" + equipes[i] + "': ");
						design[i] = kb.nextDouble();
						
						if (design[i] >= 0.00 && design[i] <= 10.00) {
							i++;
							k++;
						} else {
							System.err.println("Nota inválida, tente novamente.\n");
						}
					}
				}
			}
		System.out.println();
		
		// Inicialização de métodos
		
		int[] nota = notas(equipes, quantia);
		int[] pontuacao = ffa(equipes, quantia, design, nota);
		int[] finalistas = finalistas(pontuacao, equipes, design);
		int[] finalistasPont = finalistasPontuacao(pontuacao, equipes, design);
//		int[] finalistasNotas = finalistasNota();
		
		}
		kb.close();
	}
	
	public static int[] notas(int[] equipes, int quantia) {
		Random rng = new Random();
		
		int[] nota = new int[quantia];

		for (int i = 0; i < quantia; i++) {
			for (int j = 0; j < quantia; j++) {
				if (i < j) {
					nota[i] = rng.nextInt(11);
					nota[j] = rng.nextInt(11);
				}
			}
		}
		
		return nota;
	}
	
	public static int[] ffa(int[] equipes, int quantia, double[] design, int[] nota) {
		
		int[] batalhas = new int[quantia];
		int[] pontuacao = new int[quantia];
		int[] resultado = new int[quantia];
		
		// Batalhas - Resultados por notas aleatórias
		
		for (int i = 0; i < batalhas.length; i++) {
			for (int j = 0; j < quantia; j++) {
				if (i < j) {
					System.out.println("\nBatalha entre as equipes: '" + equipes[i] + "'x'" + equipes[j] + "'.");
					System.out.print("\nNota de batalha da equipe '" + equipes[i] + "': " + nota[i]);
					System.out.print("\nNota de batalha da equipe '" + equipes[j] + "': " + nota[j]);
					
					if (nota[i] == nota[j]) {
						System.out.print("\nEmpate, vencedor decidido via nota de design:");
						System.out.print("\nEquipe '" + equipes[i] + "' = " + design[i]);
						System.out.print("\nEquipe '" + equipes[j] + "' = " + design[j]);
						if (design[i] > design[j]) { 
							nota[i] += 1;
						} else {
							nota[j] += 1;
						}
					}
					if (nota[i] > nota[j]) {
						pontuacao[i] += 5;
						resultado[i] = equipes[i];
					}	
					else if (nota[i] < nota[j]) {
						pontuacao[j] += 5;
						resultado[i] = equipes[j];
					}
					System.out.println("\nEquipe vencedora: '" + resultado[i] + "'. (+5)");
					System.out.print("================================================");
				}
			}
		}
		
		System.out.println("\n");
		System.out.println("Pontuação");
		
		for (int i = 0; i < equipes.length; i++) {
			System.out.print("\nEquipe '" + equipes[i] + "': "+ pontuacao[i] + " pontos.");
			System.out.println("\nNota de design: " + design[i]);
		}

		return pontuacao;
	}
	
	public static int[] finalistas(int[]pontuacao, int[] equipes, double[] design) {
		int[] finalistas = new int[3];
		
		System.out.println("\n");
		System.out.println("Ranking:");
		
		// Ordenação - Ordem crescente pra inserção em tabela
		
		for (int j = 0; j < equipes.length; j++) {
			for (int i = 0; i < equipes.length-1; i++) {
				boolean bool = false;
				if (pontuacao[i] < pontuacao[i+1]) {
					bool = true;
				}
				else if (pontuacao[i] == pontuacao[i+1]) {
					if (design[i] < design[i+1]) {
						bool = true;
					}
				}
				if (bool) {
					int aux = pontuacao[i];
					pontuacao[i] = pontuacao[i+1];
					pontuacao[i+1] = aux;
					
					aux = equipes[i];
					equipes[i] = equipes[i+1];
					equipes[i+1] = aux; 
					
					double auxDesign = design[i];
					design[i] = design[i+1];
					design[i+1] = auxDesign;
				}
			}
		}

		for (int i = 0; i < equipes.length; i++) {
			System.out.println("Equipe: '" + equipes[i] + "' com " + pontuacao[i] + " pontos. Nota de design: " + design[i] + ".");
		}
		
		System.out.println("\nFinalistas: ");
		
		for (int i = 0; i < 3; i++) {
			finalistas[i] = equipes[i];
			System.out.print("Equipe: '" + finalistas[i] + "'\n");
		}
		
		return finalistas;
	}
	
	public static int[] finalistasPontuacao(int[]pontuacao, int[] equipes, double[] design) {
		int[] finalistasPont = new int[3];
		
		for (int i = 0; i < 2; i++) {
			finalistasPont[i] = equipes[i];
		}
		
		return finalistasPont;
	}
}