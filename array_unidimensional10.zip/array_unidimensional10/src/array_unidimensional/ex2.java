package array_unidimensional;

import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		int[] valor = new int[5];
		// declaração de vetor (variavel que armazena varios elementos)
		
		int impar = 0;
		
		// i = indice que controle a variavel
		for (int i = 0; i < valor.length; i++) {
			System.out.print("Informe um valor: ");
			valor[i] = kb.nextInt();
			if(valor[i] % 2 != 0) {
				impar++;
			}
		}
		System.out.println("Total de impares: " + impar);
		System.out.println("Total de pares " + (valor.length - impar));
	}
}