package listaExerciciosMatriz;

import java.util.Random;

public class ex05 {

	public static void main(String[] args) {
		Random rng = new Random();
		int pares = 0, impares = 0;
		
		int[][] matriz = new int[10][10];
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				matriz[i][j] = rng.nextInt(101);
				System.out.print(matriz[i][j] + "\t");
			}
			System.out.println();
		}
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				if (matriz[i][j] % 2 == 0) {
					pares++;
				} else {
					impares++;
				}
			}
		}
		
		System.out.print("\nQuantia de pares: " + pares);
		System.out.print("\nQuantia de ímpares: " + impares);

	}

}
