import java.util.Scanner;

public class exercicio01 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		int[] vetor = new int[5];
		int maior = Integer.MIN_VALUE, menor = Integer.MAX_VALUE;
		
		for (int i = 0; i < vetor.length; i++) {
			System.out.println("Informe um valor: ");
			vetor[i] = kb.nextInt();
			
			if (vetor[i] > maior) {
				maior = vetor[i];
			}
			if (vetor[i] < menor){
				menor = vetor[i];
			}
		}
		System.out.print("Maior número informado: " + maior);
		System.out.println(" ");
		System.out.print("Menor número informado: " + menor);
		
		kb.close();
	}

}
