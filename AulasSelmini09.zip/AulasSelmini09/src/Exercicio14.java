import java.util.Scanner; 

public class Exercicio14 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		int n;
		double y = 0;
		
		System.out.println("Informe um valor à ser calculado.");
		n = kb.nextInt();
		
		for (int cont = 1; cont <= y; cont++) {
			y =  y + (double) 1 / cont;
		}
		System.out.println(y);
	}

}
