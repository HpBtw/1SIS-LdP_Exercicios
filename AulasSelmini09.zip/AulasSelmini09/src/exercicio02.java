import java.util.Scanner; 

public class exercicio02 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		int numero, fator = 0;
		String frase = "";
		
			while (fator <= 10 && frase != "nao") {
				System.out.println("Insira um número para calcular sua tabulada, escreva 'calcular' para repetir o programa, e 'nao' para finalizar a aplicação.");
				frase = kb.next();
				numero = kb.nextInt();
				System.out.println("Por " + fator + " = " + numero * fator);
				fator = fator + 1;
				}
			System.out.println("Programa finalizado");
			
			kb.close();
		}
}